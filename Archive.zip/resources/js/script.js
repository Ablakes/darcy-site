$(document).ready(function(){
    $('.your-class').slick({
      infinite: true,
      slidesToShow: 2,
      slidesToScroll: 3
    });
});
